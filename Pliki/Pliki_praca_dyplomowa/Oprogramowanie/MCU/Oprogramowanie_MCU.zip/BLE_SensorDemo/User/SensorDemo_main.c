/******************** (C) COPYRIGHT 2018 STMicroelectronics ********************
* File Name          : SensorDemo_main.c
* Author             : AMS - RF Application team
* Version            : V1.2.0
* Date               : 03-December-2018
* Description        : BlueNRG-1-2 Sensor Demo main file 
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/
/** @addtogroup BlueNRG1_demonstrations_applications
 * BlueNRG-1,2 SensorDemo \see SensorDemo_main.c for documentation.
 *
 *@{
 */

/** @} */
/** \cond DOXYGEN_SHOULD_SKIP_THIS
 */
/* Includes ------------------------------------------------------------------*/
#include <stdio.h>
#include "BlueNRG1_it.h"
#include "BlueNRG1_conf.h"
#include "ble_const.h" 
#include "bluenrg1_stack.h"
#include "SDK_EVAL_Config.h"
#include "sleep.h"
#include "sensor.h"
#include "clock.h"
#include "SensorDemo_config.h"
#include "OTA_btl.h"  
#include "gatt_db.h"
#include "BlueNRG1_adc.h"
#include "BlueNRG1_dma.h"
#include <string.h>
uint16_t iteration_count = 0;
/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#ifndef DEBUG
#define DEBUG 0
#endif
#define TIMER_INTERVAL_MS (1000 / 5000) // 1000 ms / 5k samples = 0.2 ms per sample
#if DEBUG
#include <stdio.h>
#define PRINTF(...) printf(__VA_ARGS__)
#else
#define PRINTF(...)
#endif
/* Private macro -------------------------------------------------------------*/
#define  size     (2)
#define BLE_SENSOR_VERSION_STRING "1.0.0" 

/* Private macro -------------------------------------------------------------*/

/* Defines ADC----------------------------------------------*/
#define ADC_OUT_ADDRESS         (ADC_BASE + 0x16)
#define ADC_DMA_CH0             (DMA_CH0)
#define MAX_NUM_PACKET           100
#define LEN      (18) //100
#define LEN1      (20) //100
#define LEN2       (10)
#define SLEEP_CLOCK_ACCURACY        100
#define RESTET MANAGER SIZE 0;

/* Defines I2C----------------------------------------------*/
/* I2C Device address */
#define DEV_ADDRESS             0x2E
/* I2C clock frequency */
#define I2C_CLK_SPEED  (10000)
//# define int LEN=100;
/* Private typedef -----------------------------------------------------------*/
typedef enum {
  I2C_OP_FAILED = 0,
  I2C_OP_SUCCEED
}
I2C_AppOpStatus;

/* BUFFORY ADC-----------------------------------------------*/
uint16_t buffer_adc[LEN];
//uint8_t buffer_adc_send[LEN-50];
//uint8_t buffer_adc_send1[LEN-50];
uint8_t buffer_adc_send[LEN1];
uint8_t buffer_adc_send1[LEN];
uint16_t buffer[LEN];
uint8_t UpdateCharData[LEN];
uint8_t m;
uint8_t g;
uint16_t z;

/* Defines I2C-----------------------------------------------*/
uint8_t len=size;
uint8_t xbu=size-1;
//uint8_t buffer[size];
uint8_t bufferRead[size];
uint8_t buffercheck[size-1];
uint8_t pBuffer[size];
uint8_t ReadBuffer[size];
uint8_t ReadEmptyBuffer[size-1];
uint8_t FReadEmptyBuffer[size+2];
uint16_t buffer_test[9] = { 12000, 15000, 33800, 5400, 24500, 6700, 7500, 16000, 7800 };

/* Prototypy funkcji ADC DMA-----------------------------------------------*/
void ADC_Configuration(void);
void DMA_Configuration(void);
void APP_Tick1(void);
void APP_Tick2(void);
/* Prototypy funkcji I2C-----------------------------------------------*/
int I2C_WRITE_MCP40D18T(uint8_t* pBuffer, uint8_t DeviceAddr,  uint8_t NumByteToWrite);
int I2C_READ_MCP40D18TV2(uint8_t*, uint8_t,uint8_t ,uint8_t,uint8_t*);
int I2C_READ_MCP40D18TV1(uint8_t* , uint8_t , uint8_t,uint8_t*  );
void i2c_init(void);
void I2C_ConfigurationMaster(void);
/* Private variables ---------------------------------------------------------*/

void process_buffer(uint16_t *buffer_adc, uint8_t *temp_buffer, uint8_t *buffer_adc_send1, uint16_t start_idx, uint16_t len);
/* Set the Application Service Max number of attributes records with init parameters coming from application *.config.h file */
uint8_t Services_Max_Attribute_Records[NUMBER_OF_APPLICATION_SERVICES] = {MAX_NUMBER_ATTRIBUTES_RECORDS_SERVICE_1, MAX_NUMBER_ATTRIBUTES_RECORDS_SERVICE_2};
//uint16_t buffer_adc[ADC_DMA_BUFFER_LEN];
//uint16_t buffer_adc_send[ADC_DMA_BUFFER_LEN-50];
//uint8_t UpdateCharData[LEN];
//uint32_t DMA32[50];
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/
/* DMA Initialization */
uint32_t start_time, end_time, elapsed_time;
int main(void) 
{
  uint8_t ret;
//  uint8_t i;
  /* System Init */
  SystemInit();
  DMA_Configuration();
 // for(uint8_t i=0;i< LEN ;i++){
  tClockTime prev_tick;

    // Initialize prev_tick
    prev_tick = Clock_Time();
     //	 buffer[i]=100;

     //  }
     /* ADC Initialization */
     ADC_Configuration();

     /* ADC Initialization */
     ADC_DmaCmd(ENABLE);

     /* Start new conversion */
     ADC_Cmd(ENABLE);
  
  /* Identify BlueNRG1 platform */
  SdkEvalIdentification();

  /* Configure I/O communication channel */
  SdkEvalComUartInit(UART_BAUDRATE);

  /* BlueNRG-1,2 stack init */
  ret = BlueNRG_Stack_Initialization(&BlueNRG_Stack_Init_params);
  if (ret != BLE_STATUS_SUCCESS) {
    PRINTF("Error in BlueNRG_Stack_Initialization() 0x%02x\r\n", ret);
    while(1);
  }

  /* Application demo Led Init */
  SdkEvalLedInit(LED1); //Activity led
  SdkEvalLedInit(LED3); //Error led
  SdkEvalLedOn(LED1);
  SdkEvalLedOff(LED3);

  PRINTF("BlueNRG-1,2 BLE Sensor Demo Application (version: %s)\r\n", BLE_SENSOR_VERSION_STRING);
  
#if ST_USE_OTA_SERVICE_MANAGER_APPLICATION
  /* Initialize the button: to be done before Sensor_DeviceInit for avoiding to 
     overwrite pressure/temperature sensor IO configuration when using BUTTON_2 (IO5) */
  SdkEvalPushButtonInit(USER_BUTTON);
#endif /* ST_USE_OTA_SERVICE_MANAGER_APPLICATION */
  
  /* Sensor Device Init */
  ret = Sensor_DeviceInit();
  if (ret != BLE_STATUS_SUCCESS) {
    SdkEvalLedOn(LED3);
    while(1);
  }


  while(1)
  {
    /* BLE Stack Tick */
    BTLE_StackTick();

    /* Application Tick */
    Set_DeviceConnectable();
APP_Tick2();


    /*
    for(uint8_t i=0;i< 10 ;i++){
    buffer_adc_send1[2*i]=buffer_test[i]>>8;
    buffer_adc_send1[2*i+1]=buffer_test[i]&0xFF;}
    ADC_Update1((uint8_t*)buffer_adc_send1,LEN);
*/
//

            // APP_Tick1();

    /* Power Save management */
   // BlueNRG_Sleep(SLEEPMODE_NOTIMER, 0, 0);
    
#if ST_OTA_FIRMWARE_UPGRADE_SUPPORT
    /* Check if the OTA firmware upgrade session has been completed */
    if (OTA_Tick() == 1)
    {
      /* Jump to the new application */
      OTA_Jump_To_New_Application();
    }
#endif /* ST_OTA_FIRMWARE_UPGRADE_SUPPORT */

#if ST_USE_OTA_SERVICE_MANAGER_APPLICATION
    if (SdkEvalPushButtonGetState(USER_BUTTON) == RESET)
    {
      OTA_Jump_To_Service_Manager_Application();
    }
#endif /* ST_USE_OTA_SERVICE_MANAGER_APPLICATION */
  }/* while (1) */
}

/* Hardware Error event. 
   This event is used to notify the Host that a hardware failure has occurred in the Controller. 
   Hardware_Code Values:
   - 0x01: Radio state error
   - 0x02: Timer overrun error
   - 0x03: Internal queue overflow error
   After this event is recommended to force device reset. */

void hci_hardware_error_event(uint8_t Hardware_Code)
{
   NVIC_SystemReset();
}

/**
  * This event is generated to report firmware error informations.
  * FW_Error_Type possible values: 
  * Values:
  - 0x01: L2CAP recombination failure
  - 0x02: GATT unexpected response
  - 0x03: GATT unexpected request
    After this event with error type (0x01, 0x02, 0x3) it is recommended to disconnect. 
*/
void aci_hal_fw_error_event(uint8_t FW_Error_Type,
                            uint8_t Data_Length,
                            uint8_t Data[])
{
  if (FW_Error_Type <= 0x03)
  {
    uint16_t connHandle;
    
    /* Data field is the connection handle where error has occurred */
    connHandle = LE_TO_HOST_16(Data);
    
    aci_gap_terminate(connHandle, BLE_ERROR_TERMINATED_REMOTE_USER); 
  }
}
/*******************************************************************************
 * Function Name  : ADC_Configuration.
 * Description    : ADC Configuration .
 * Input          : None.
 * Output         : None.
 * Return         : None.
 *******************************************************************************/
void ADC_Configuration(void)
{
  SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_ADC, ENABLE);
  ADC_InitType xADC_InitType;
  xADC_InitType.ADC_OSR = ADC_OSR_200;
  xADC_InitType.ADC_Input = ADC_Input_AdcPin1; //ADC_Input_AdcPin12;
  xADC_InitType.ADC_ConversionMode = ADC_ConversionMode_Continuous;
  xADC_InitType.ADC_ReferenceVoltage =  ADC_ReferenceVoltage_0V6; //ADC_ReferenceVoltage_0V6;
  xADC_InitType.ADC_Attenuation = ADC_Attenuation_0dB;//ADC_Attenuation_9dB54

  ADC_Init(&xADC_InitType);

  /* Enable auto offset correction */
  ADC_AutoOffsetUpdate(ENABLE);
  ADC_Calibration(ENABLE);
}
/*******************************************************************************
 * Function Name  : DMA_Configuration.
 * Description    : DMA Configuration .
 * Input          : None.
 * Output         : None.
 * Return         : None.
 *******************************************************************************/
void DMA_Configuration(void)
{
  DMA_InitType DMA_InitStructure;

  SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_DMA, ENABLE);

  /* DMA_CH_UART_TX Initialization */
  DMA_InitStructure.DMA_PeripheralBaseAddr = ADC_OUT_ADDRESS;
  DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)buffer_adc;
  DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;
  DMA_InitStructure.DMA_BufferSize = (uint32_t)LEN;
  DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
  DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
  DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
  DMA_InitStructure.DMA_Mode = DMA_Mode_Circular; //DMA_Mode_Circular;
  DMA_InitStructure.DMA_Priority = DMA_Priority_High;
  DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
  DMA_Init(ADC_DMA_CH0, &DMA_InitStructure);

  /* Enable DMA ADC CHANNEL 0 Transfer Complete interrupt */
  DMA_FlagConfig(ADC_DMA_CH0, DMA_FLAG_TC, ENABLE);
  DMA_FlagConfig(ADC_DMA_CH0, DMA_FLAG_HT, ENABLE);

  /* Select DMA ADC CHANNEL 0 */
  DMA_SelectAdcChannel(DMA_ADC_CHANNEL0, ENABLE);

  /* Enable DMA ADC CHANNEL 0 */
  DMA_Cmd(ADC_DMA_CH0, ENABLE);
}
/****************** BlueNRG-1,2 Sleep Management Callback ********************************/

SleepModes App_SleepMode_Check(SleepModes sleepMode)
{
  if(request_free_fall_notify || SdkEvalComIOTxFifoNotEmpty() || SdkEvalComUARTBusy())
    return SLEEPMODE_RUNNING;
  
  return SLEEPMODE_NOTIMER;
}

/***************************************************************************************/
void i2c_init(void) {
  /* Periph clock enable */
  SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_GPIO | CLOCK_PERIPH_I2C1, ENABLE);

  // I2C2 pins
  GPIO_InitI2c1ClkPin14(); // SCL at DIO4
  GPIO_InitI2c1DataPin15(); // SDA at DIO5

  I2C_InitType i2c_settings;
  I2C_StructInit( & i2c_settings);
  i2c_settings.I2C_ClockSpeed = 100000;
  i2c_settings.I2C_OperatingMode = I2C_OperatingMode_Master;

  I2C_Init(I2C1, & i2c_settings);

  I2C_ClearITPendingBit(I2C1, I2C_IT_MSK);

  I2C_Cmd(I2C1, ENABLE);
}
void I2C_ConfigurationMaster(void)
{
  GPIO_InitType GPIO_InitStructure;
  I2C_InitType I2C_InitStruct;

  /* Enable I2C and GPIO clocks */
  if(I2C1== I2C1) {
    SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_I2C1 | CLOCK_PERIPH_GPIO, ENABLE);
  }
  else {
    SysCtrl_PeripheralClockCmd(CLOCK_PERIPH_I2C1 | CLOCK_PERIPH_GPIO, ENABLE);
  }

  /* Configure I2C pins */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14 ;
  GPIO_InitStructure.GPIO_Mode = Serial1_Mode ;
  GPIO_InitStructure.GPIO_Pull = ENABLE;
  GPIO_InitStructure.GPIO_HighPwr = DISABLE;
  GPIO_Init(&GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
  GPIO_InitStructure.GPIO_Mode = Serial1_Mode;
  GPIO_Init(&GPIO_InitStructure);

  /* Configure I2C in master mode */
  I2C_StructInit(&I2C_InitStruct);
  I2C_InitStruct.I2C_OperatingMode = I2C_OperatingMode_Master;
  I2C_InitStruct.I2C_ClockSpeed = I2C_CLK_SPEED;
  I2C_Init(I2C1, &I2C_InitStruct);

  /* Clear all I2C pending interrupts */
  I2C_ClearITPendingBit(I2C1, I2C_IT_MSK);

}

int I2C_WRITE_MCP40D18T(uint8_t* pBuffer, uint8_t DeviceAddr, uint8_t NumByteToWrite){
    I2C_TransactionType t;

    // Zapisz adres urz�dzenia I2C
    t.Operation = I2C_Operation_Write;
    t.Address = DeviceAddr;
    t.StartByte = I2C_StartByte_Enable;
    t.AddressType = I2C_AddressType_7Bit;
    t.StopCondition = I2C_StopCondition_Enable;
    t.Length = NumByteToWrite;

    // Wyczyszczenie bufora TX
    I2C_FlushTx(I2C1);

    // Zapisz adres urz�dzenia I2C i umie�� warto�� send_val w buforze TX FIFO
    I2C_BeginTransaction(I2C1, &t);

    // Wype�nienie bufora TX FIFO danymi do wys�ania
    for(uint8_t i=0; i<NumByteToWrite;i++) {
        I2C_FillTxFIFO(I2C1, pBuffer[i]);
    }

    // P�tla oczekiwania
    do {
        if(I2C_OP_ABORTED == I2C_GetStatus(I2C1))
            return I2C_OP_FAILED;
    }
    while (I2C_GetITStatus(I2C1, I2C_IT_MTD) == RESET);

    // Wyczyszczenie bit�w oczekiwania
    I2C_ClearITPendingBit(I2C1, I2C_IT_MTD | I2C_IT_MTDWS);

    return SUCCESS;
}
int I2C_READ_MCP40D18TV1(uint8_t* pBuffer, uint8_t DeviceAddr, uint8_t NumByteToWrite,uint8_t* gBuffer){
    I2C_TransactionType t;

    // Ustawienie parametr�w transakcji I2C dla operacji zapisu
    t.Operation = I2C_Operation_Write;
    t.Address = DeviceAddr;
    t.StartByte = I2C_StartByte_Enable;
    t.AddressType = I2C_AddressType_7Bit;
    t.StopCondition = I2C_StopCondition_Disable;
    t.Length =  NumByteToWrite;

    // Wyczyszczenie bufora Tx
    I2C_FlushTx(I2C1);
    while (I2C_WaitFlushTx(I2C1) == I2C_OP_ONGOING);

    // Rozpocz�cie transakcji
    I2C_BeginTransaction(I2C1, &t);

    // Wype�nienie FIFO Tx
    I2C_FillTxFIFO(I2C1, pBuffer[0]);

    // Czekanie na zako�czenie operacji
    do {
        if(I2C_GetStatus(I2C1) == I2C_OP_ABORTED)
            return ERROR;
    } while (I2C_GetITStatus(I2C1, I2C_IT_MTD) == RESET);

    // Wyczyszczenie bit�w oczekiwania
    I2C_ClearITPendingBit(I2C1,I2C_IT_MTD | I2C_IT_MTDWS);

    // Pobranie danych z bufora RX
    while( NumByteToWrite--) {
        *pBuffer = I2C_ReceiveData(I2C1);
        pBuffer ++;
    }

    return SUCCESS;
}

int I2C_READ_MCP40D18TV2(uint8_t* pBuffer, uint8_t DeviceAddr,uint8_t NumByteToWrite,uint8_t NumByteToRead,uint8_t* xBuffer)
{
    I2C_TransactionType t;

    // Ustawienie parametr�w transakcji I2C dla operacji zapisu
    t.Operation = I2C_Operation_Write;
    t.Address = DeviceAddr;
    t.StartByte = I2C_StartByte_Enable;
    t.AddressType = I2C_AddressType_7Bit;
    t.StopCondition = I2C_StopCondition_Disable;
    t.Length =  NumByteToWrite;

    // Wyczyszczenie bufora Tx
    I2C_FlushTx(I2C1);
    while (I2C_WaitFlushTx(I2C1) == I2C_OP_ONGOING);

    // Rozpocz�cie transakcji
    I2C_BeginTransaction(I2C1, &t);
    for (uint8_t i = 0; i < NumByteToWrite; i++) {
        I2C_FillTxFIFO(I2C1, pBuffer[i]);
    }

    // Czekanie na zako�czenie operacji
    do {
        if (I2C_GetStatus(I2C1) == I2C_OP_ABORTED) {
            // Tutaj zwracany jest b��d
            return ERROR;
        }
    } while  (I2C_GetITStatus(I2C1, I2C_IT_MTDWS) == RESET);

    // Wyczyszczenie
    // Wyczyszczenie bit�w oczekiwania
      I2C_ClearITPendingBit(I2C1, I2C_IT_MTDWS);

      // Odczyt danych
      t.Operation = I2C_Operation_Read;
      t.Address = DeviceAddr;
      t.StartByte = I2C_StartByte_Enable;
      t.AddressType = I2C_AddressType_7Bit;
      t.StopCondition = I2C_StopCondition_Disable;
      t.Length = NumByteToRead;
      I2C_BeginTransaction(I2C1, &t);

      // P�tla oczekiwania
      do {
          if(I2C_OP_ABORTED == I2C_GetStatus(I2C1))
              return ERROR;
      }
      while (RESET == I2C_GetITStatus(I2C1, I2C_IT_MTD));

      // Wyczyszczenie bit�w oczekiwania
      I2C_ClearITPendingBit(I2C1,I2C_IT_MTD | I2C_IT_MTDWS);

      // Pobranie danych z bufora RX
      while(NumByteToRead--) {
          *xBuffer = I2C_ReceiveData(I2C1);
          xBuffer++;
      }

      return SUCCESS;
  }


void process_buffer(uint16_t *buffer_adc, uint8_t *temp_buffer, uint8_t *buffer_adc_send1, uint16_t start_idx, uint16_t len) {
    for (uint8_t i = 0; i < len; i++) {
        temp_buffer[2 * i] = buffer_adc[start_idx + i] >> 8;
        temp_buffer[2 * i + 1] = buffer_adc[start_idx + i] & 0xFF;
    }
    memcpy(buffer_adc_send1, temp_buffer, 2 * len);
    ADC_Update1(buffer_adc_send1, 2 * len);
}
void APP_Tick1(void) {


	if (DMA_GetFlagStatus(DMA_FLAG_HT)) {
	    // Process the first half of the buffer
	    for (uint8_t i = 0; i < LEN / 2; i++) {
	        buffer_adc_send[2 * i] = (buffer_adc[i] >> 8) & 0xFF;
	        buffer_adc_send[2 * i + 1] = buffer_adc[i] & 0xFF;
	    }

	    // Increment the iteration_count and store it in the last two positions
	//    iteration_count++;
	//    buffer_adc_send[LEN1 - 1] = (iteration_count >> 8) & 0xFF;
	//  buffer_adc_send[LEN1 - 2] = iteration_count & 0xFF;

	    // Clear the DMA half-transfer flag
	    DMA_ClearFlag(DMA_FLAG_HT);
	    // Update the ADC data
	    ADC_Update1((uint8_t *)buffer_adc_send, LEN1);
	}

	// Check if the DMA transfer complete flag is set
	if (DMA_GetFlagStatus(DMA_FLAG_TC)) {
	    // Process the second half of the buffer
	    for (uint8_t i = LEN / 2; i < LEN; i++) {
	        buffer_adc_send1[2 * (i - LEN / 2)] = (buffer_adc[i] >> 8) & 0xFF;
	        buffer_adc_send1[2 * (i - LEN / 2) + 1] = buffer_adc[i] & 0xFF;
	    }

	    // Increment the iteration_count and store it in the last two positions
	  //  iteration_count++;
	 //  buffer_adc_send1[LEN1 - 1] = (iteration_count >> 8) & 0xFF;
	//   buffer_adc_send1[LEN1 - 2] = iteration_count & 0xFF;

	    // Clear the DMA transfer complete flag
	    DMA_ClearFlag(DMA_FLAG_TC);
	    // Update the ADC data
	    ADC_Update1((uint8_t *)buffer_adc_send1, LEN1);
	}
}

void APP_Tick2(void) {
    if (DMA_GetFlagStatus(DMA_FLAG_HT)) {
        // Process the first half of the buffer
        for (uint8_t i = 0; i < 9; i++) {
            buffer_adc_send[2 * i] = (buffer_test[i] >> 8) & 0xFF;
            buffer_adc_send[2 * i + 1] = buffer_test[i] & 0xFF;
        }

        // Increment iteration_count and store it in the last two positions
        iteration_count++;
        buffer_adc_send[LEN1 - 1] = (iteration_count >> 8) & 0xFF;
        buffer_adc_send[LEN1 - 2] = iteration_count & 0xFF;

        // Clear the DMA half-transfer flag
        DMA_ClearFlag(DMA_FLAG_HT);
        // Update ADC data
        ADC_Update1((uint8_t *)buffer_adc_send, LEN1);
    }

    if (DMA_GetFlagStatus(DMA_FLAG_TC)) { // Check for the DMA full transfer flag
        // Process the second half of the buffer
        for (uint8_t i = 0; i < 9; i++) {
            buffer_adc_send1[2 * i] = (buffer_test[i] >> 8) & 0xFF;
            buffer_adc_send1[2 * i + 1] = buffer_test[i] & 0xFF;
        }

        // Increment iteration_count and store it in the last two positions
        iteration_count++;
        buffer_adc_send1[LEN1 - 1] = (iteration_count >> 8) & 0xFF;
        buffer_adc_send1[LEN1 - 2] = iteration_count & 0xFF;

        // Clear the DMA full transfer flag
        DMA_ClearFlag(DMA_FLAG_TC);
        // Update ADC data
        ADC_Update1((uint8_t *)buffer_adc_send1, LEN1);
    }
}
#ifdef USE_FULL_ASSERT
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert_param error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert_param error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(uint8_t* file, uint32_t line)
{
    /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
    
    /* Infinite loop */
    while (1)
    {}
}
#endif

/******************* (C) COPYRIGHT 2015 STMicroelectronics *****END OF FILE****/
/** \endcond
 */
