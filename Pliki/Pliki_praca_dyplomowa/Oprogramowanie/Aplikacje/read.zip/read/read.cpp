#include <atomic>
#include <chrono>
#include <condition_variable>
#include <fstream>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <thread>
#include <sstream>
#include <vector>
#include "../common/utils.hpp"
#include <thread>
#include <future>
#include <memory>
#include <functional>
#include "simpleble/SimpleBLE.h"
using namespace std;


using namespace std::chrono_literals;
void cls() { std::cout << "\033[2J\033[1;1H"; }
void writerThreadFunc(const std::vector<char>& buffer, std::ofstream& fout) {
    for (size_t i = 0; i < buffer.size(); i++) {
        fout << std::hex << std::setw(2) << std::setfill('0') << (int)(unsigned char)buffer[i] << " ";
    }
}

int main() {
    auto adapter_optional = Utils::getAdapter();

    if (!adapter_optional.has_value()) {
        return EXIT_FAILURE;
    }

    auto adapter = adapter_optional.value();

    std::vector<SimpleBLE::Peripheral> peripherals;

    adapter.set_callback_on_scan_found([&](SimpleBLE::Peripheral peripheral) {
        std::cout << "Znaleziono: " << peripheral.identifier() << " [" << peripheral.address() << "]" << std::endl;
        peripherals.push_back(peripheral);
    });

    adapter.set_callback_on_scan_start([]() { std::cout << "Skanowanie." << std::endl; });
    adapter.set_callback_on_scan_stop([]() { std::cout << "Skanowanie zakonczone." << std::endl; });
    // Scan for 5 seconds and return.
    adapter.scan_for(3000);

    std::cout << "Znaleziono urzadzenie:" << std::endl;
    for (size_t i = 0; i < peripherals.size(); i++) {
        std::cout << "[" << i << "] " << peripherals[i].identifier() << " [" << peripherals[i].address() << "]"
                  << std::endl;
    }

    auto selection = Utils::getUserInputInt("WYBIERZ URZADZENIE Z KTORYM CHCESZ SIE POLOCZYC", peripherals.size() - 1);

    if (!selection.has_value()) {
        return EXIT_FAILURE;
    }

    auto peripheral = peripherals[selection.value()];
    std::cout << "LACZENIE Z " << peripheral.identifier() << " [" << peripheral.address() << "]" << std::endl;
    peripheral.connect();

    std::vector<std::pair<SimpleBLE::BluetoothUUID, SimpleBLE::BluetoothUUID>> uuids;
    for (auto service : peripheral.services()) {
        for (auto characteristic : service.characteristics()) {
            uuids.push_back(std::make_pair(service.uuid(), characteristic.uuid()));
        }
    }
    cls();

                                               std::cout << "NAZWA:" << peripheral.identifier() << std::endl;
                                               std::cout << "MENU" << std::endl;
    int pick = 0;
    bool quit = false;

    do {
                          std::cout << "WYBIERZ OPCJE:" << endl
                                                  << "[1] Subskrypcja charkaterystyki noatyfikjacyjnej" << endl
                                                  << "[2] Rozloancz z urzadzeniem"                      << endl
                                                  << "[3] Subskrypcja charkaterystyki write"            << endl
                                                  << "[4] Subskrycja charakterystki read"               << endl
                                                  << "[5] Pokaz seriwsy oraz charakterystyki"           << endl
                                                  << "[6] Pokaz pramatery transmisji urzadzenia"        << endl;
        std::cin >> pick;
        int bufferCount;
        if (pick == 1) {
    
            std::vector<std::pair<SimpleBLE::BluetoothUUID, SimpleBLE::BluetoothUUID>> uuids;
            for (auto service : peripheral.services()) {
                for (auto characteristic : service.characteristics()) {
                    uuids.push_back(std::make_pair(service.uuid(), characteristic.uuid()));
                }
            }

            std::cout << "Nast�pujace charakterystyki zostaly znalezione:" << std::endl;
            for (size_t i = 0; i < uuids.size(); i++) {
                std::cout << "[" << i << "] " << uuids[i].first << " " << uuids[i].second << std::endl;
            }

            selection = Utils::getUserInputInt("Wybierz charakterystyke do subskypcji", uuids.size() - 1);

            if (!selection.has_value()) {
                return EXIT_FAILURE;
            }
            size_t buffer_size = 5000;
            std::cout << "Podaj liczbe buforow do wype�nienia (kazdy posiada 5k sampli) : ";
            size_t num_buffers_to_fill;
            std::cin >> num_buffers_to_fill;

            size_t total_bytes_received = 0;
            size_t total_notifications_received = 0;
            std::string file_name;
            std::cout << "Wprowadz nazwe pliku, w ktorym zosan� zapisane dane: ";
            std::cin.ignore(); 
            std::getline(std::cin, file_name);

           
            std::vector<SimpleBLE::ByteArray> received_data_buffer;

            std::chrono::high_resolution_clock::time_point start_time, end_time;
            std::atomic<bool> done(false);
            std::mutex data_mutex;
            std::condition_variable done_cv;

            received_data_buffer.reserve(num_buffers_to_fill);

            peripheral.notify(
                uuids[selection.value()].first, uuids[selection.value()].second, [&](SimpleBLE::ByteArray bytes) {
                    std::unique_lock<std::mutex> lock(data_mutex);
                    std::cout << "Otrzymano: ";
                    Utils::print_byte_array(bytes);
                    if (total_notifications_received == 0) {
                        
                        start_time = std::chrono::high_resolution_clock::now();
                    }

                    
                    received_data_buffer.push_back(bytes);

                    total_bytes_received += bytes.size();
                    total_notifications_received++;
                    if (total_bytes_received >= num_buffers_to_fill * buffer_size) {
                        peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
                        end_time = std::chrono::high_resolution_clock::now();  // Store the end time
                        done = true;
                        done_cv.notify_one();
                    }
                });

            std::unique_lock<std::mutex> lock(data_mutex);
            done_cv.wait(lock, [&]() { return done.load(); });

            peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
            peripheral.disconnect();

            
            std::ofstream output_file(file_name, std::ios::out | std::ios::binary);
            for (const auto& bytes : received_data_buffer) {
                for (const auto& byte : bytes) {
                    output_file << std::hex << std::setw(2) << std::setfill('0')
                                << static_cast<unsigned int>(static_cast<unsigned char>(byte)) << " ";
                }
                output_file << std::endl;
            }
            output_file.close();

            std::chrono::duration<double> elapsed_time = end_time - start_time;
            std::cout << "Czas notyfikacji wyniosl : " << elapsed_time.count() << " s" << std::endl;
        }
         else if (pick == 2) {
                std::cout << "\t ROZLONCZONO Z URZADZENIEM" << endl;
               
                peripheral.disconnect();
                break;
            } else if (pick == 3) {
            std::vector<std::pair<SimpleBLE::BluetoothUUID, SimpleBLE::BluetoothUUID>> uuids;
            for (auto service : peripheral.services()) {
                for (auto characteristic : service.characteristics()) {
                    uuids.push_back(std::make_pair(service.uuid(), characteristic.uuid()));
                }
            }

            std::cout << " Nast�pujace charakterystyki zostaly znalezione : " << std::endl;
            for (size_t i = 0; i < uuids.size(); i++) {
                std::cout << "[" << i << "] " << uuids[i].first << " " << uuids[i].second << std::endl;
            }

            selection = Utils::getUserInputInt("Wybierz charakterystyke: ", uuids.size() - 1);

            std::string contents;
            std::cout << "Wpisz dane do charkaterytsyki: ";
            std::cin >> contents;

            if (!selection.has_value()) {
                return EXIT_FAILURE;
            }

            // NOTE: Alternatively, `write_command` can be used to write to a characteristic too.
            // `write_request` is for unacknowledged writes.
            // `write_command` is for acknowledged writes.
            peripheral.write_request(uuids[selection.value()].first, uuids[selection.value()].second, contents);


                if (!selection.has_value()) {
                    return EXIT_FAILURE;
                } else if (pick == 4) {
                    std::vector<std::pair<SimpleBLE::BluetoothUUID, SimpleBLE::BluetoothUUID>> uuids;
                    for (auto service : peripheral.services()) {
                        for (auto characteristic : service.characteristics()) {
                            uuids.push_back(std::make_pair(service.uuid(), characteristic.uuid()));
                        }
                    }

                    std::cout << "Nast�pujace charakterystyki zostaly znalezione:" << std::endl;
                    for (size_t i = 0; i < uuids.size(); i++) {
                        std::cout << "[" << i << "] " << uuids[i].first << " " << uuids[i].second << std::endl;
                    }

                    selection = Utils::getUserInputInt("Wybierz charakterystyke do odczytu", uuids.size() - 1);

                    if (!selection.has_value()) {
                        return EXIT_FAILURE;
                    }

                    // Attempt to read the characteristic 5 times in 5 seconds.
                    for (size_t i = 0; i < 5; i++) {
                        SimpleBLE::ByteArray rx_data = peripheral.read(uuids[selection.value()].first,
                                                                       uuids[selection.value()].second);
                        std::cout << "Dane z charkaterystyki: ";
                        Utils::print_byte_array(rx_data);
                        std::this_thread::sleep_for(1s);
                    }

               
                }
               
            } else if (pick == 5) {
                std::cout << "\t         POLOACZONO Z BLUE-NRG2." << std::endl;
                std::cout << "\t         MTU: " << peripheral.mtu() << std::endl;
                for (auto& service : peripheral.services()) {
                    std::cout << "\t     SERWIS: " << endl << service.uuid() << std::endl;

                    for (auto& characteristic : service.characteristics()) {
                        std::cout << "\t    CHARAKTERYSTYKA NALEZACA DO SERWISU : " << endl
                                  << characteristic.uuid() << std::endl;

                        std::cout << "\t ZDOLNOSCI : ";
                        for (auto& capability : characteristic.capabilities()) {
                            std::cout << capability << " ";
                        }
                        std::cout << std::endl;

                        for (auto& descriptor : characteristic.descriptors()) {
                            std::cout << "\t Descriptor: " << descriptor.uuid() << std::endl;
                        }
                    }
                }
            }

            else if (pick == 6) {
                std::cout << "\t NAZWA :" << peripheral.identifier() << std::endl;
                std::cout << "\t TX POWER: " << peripheral.tx_power() << std::endl;
                std::cout << "\t RSSI: " << peripheral.rssi() << std::endl;
                std::cout << "\t ADDRESS: " << peripheral.address() << std::endl << std::endl;

             

            }

            else {
                std::cout << "WYBIERZ POPRAWNA OPCJE " << endl;
            }
        }
        while (!quit);
    
        return EXIT_SUCCESS;

      
    }
   

