
/*
#include <chrono>
#include <iomanip>
#include <iostream>
#include <thread>
#include <vector>
#include <fstream>
#include "../common/utils.hpp"

#include <condition_variable>
#include <mutex>
#include <queue>


#include "simpleble/SimpleBLE.h"

using namespace std::chrono_literals;

int main() {
    auto adapter_optional = Utils::getAdapter();
    size_t total_bytes_received = 0;
    size_t total_notifications_received = 0;
    if (!adapter_optional.has_value()) {
        return EXIT_FAILURE;
    }

    auto adapter = adapter_optional.value();

    std::vector<SimpleBLE::Peripheral> peripherals;

    adapter.set_callback_on_scan_found([&](SimpleBLE::Peripheral peripheral) {
        std::cout << "Found device: " << peripheral.identifier() << " [" << peripheral.address() << "]" << std::endl;
        peripherals.push_back(peripheral);
    });

    adapter.set_callback_on_scan_start([]() { std::cout << "Scan started." << std::endl; });
    adapter.set_callback_on_scan_stop([]() { std::cout << "Scan stopped." << std::endl; });
    // Scan for 5 seconds and return.
    adapter.scan_for(8000);

    std::cout << "The following devices were found:" << std::endl;
    for (size_t i = 0; i < peripherals.size(); i++) {
        std::cout << "[" << i << "] " << peripherals[i].identifier() << " [" << peripherals[i].address() << "]"
                  << std::endl;
    }

    auto selection = Utils::getUserInputInt("Please select a device to connect to", peripherals.size() - 1);
    if (!selection.has_value()) {
        return EXIT_FAILURE;
    }

    auto peripheral = peripherals[selection.value()];
    std::cout << "Connecting to " << peripheral.identifier() << " [" << peripheral.address() << "]" << std::endl;
    peripheral.connect();

    std::cout << "Successfully connected, printing services and characteristics.." << std::endl;

    // Store all service and characteristic uuids in a vector.
    std::vector<std::pair<SimpleBLE::BluetoothUUID, SimpleBLE::BluetoothUUID>> uuids;
    for (auto service : peripheral.services()) {
        for (auto characteristic : service.characteristics()) {
            uuids.push_back(std::make_pair(service.uuid(), characteristic.uuid()));
        }
    }

    std::cout << "The following services and characteristics were found:" << std::endl;
    for (size_t i = 0; i < uuids.size(); i++) {
        std::cout << "[" << i << "] " << uuids[i].first << " " << uuids[i].second << std::endl;
    }

    selection = Utils::getUserInputInt("Please select a characteristic to read", uuids.size() - 1);

    if (!selection.has_value()) {
        return EXIT_FAILURE;
    }

    std::ofstream output_file("output2.txt", std::ios::out | std::ios::binary);

    std::optional<std::chrono::high_resolution_clock::time_point> first_notify_time;
    std::chrono::high_resolution_clock::time_point last_notify_time;

    // Create a queue and mutex for thread-safe data transfer
    std::queue<SimpleBLE::ByteArray> data_queue;
    std::mutex queue_mutex;
    std::condition_variable queue_cv;
    bool is_notification_finished = false;

    // Launch a separate thread for file writing
    std::thread file_writer([&]() {
        while (true) {
            std::unique_lock<std::mutex> lock(queue_mutex);
            queue_cv.wait(lock, [&]() { return !data_queue.empty() || is_notification_finished; });

            if (is_notification_finished && data_queue.empty()) {
                break;
            }

            SimpleBLE::ByteArray bytes = data_queue.front();
            data_queue.pop();
            lock.unlock();

            output_file << std::hex << std::setfill('0') << "";
            for (const auto& byte : bytes) {
                output_file << std::setw(2) << static_cast<unsigned int>(static_cast<unsigned char>(byte)) << " ";
            }
            output_file << std::endl;
            total_bytes_received += bytes.size();
            total_notifications_received++;
        }
       
    });

    peripheral.notify(uuids[selection.value()].first, uuids[selection.value()].second, [&](SimpleBLE::ByteArray bytes) {
        if (!first_notify_time.has_value()) {
            std::cout << "Received: ";
           
            // Store the start time of the first notification
            first_notify_time = std::chrono::high_resolution_clock::now();
            Utils::print_byte_array(bytes);
        }

        {
            std::unique_lock<std::mutex> lock(queue_mutex);
            data_queue.push(bytes);
        }
        queue_cv.notify_one();

        // Update the time of the last notification
        last_notify_time = std::chrono::high_resolution_clock::now();
    });

    std::this_thread::sleep_for(std::chrono::seconds(1));

    peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);

    {
        std::unique_lock<std::mutex> lock(queue_mutex);
        is_notification_finished = true;
    }
    queue_cv.notify_one();

    // Wait for the file_writer thread to finish
    file_writer.join();

    peripheral.disconnect();
    std::cout << "Total notifications received: " << total_notifications_received << std::endl;
    std::cout << "Total bytes received: " << total_bytes_received << std::endl;

    output_file.close();

    if (first_notify_time.has_value()) {
        std::chrono::duration<double> elapsed_time = last_notify_time - first_notify_time.value();
        std::cout << "Elapsed time for the full notification window: " << elapsed_time.count() << " seconds"
                  << std::endl;
    } else {
        std::cout << "No notifications were received during the window" << std::endl;
    }

    return EXIT_SUCCESS;
}
/*std::ofstream output_file("output.txt", std::ios::out | std::ios::binary);
auto start_time = std::chrono::high_resolution_clock::now();

peripheral.notify(uuids[selection.value()].first, uuids[selection.value()].second, [&](SimpleBLE::ByteArray bytes) {
    std::cout << "Received: ";
    Utils::print_byte_array(bytes);

    // Write the received data in hexadecimal human-readable form to the file.
    for (const auto& byte : bytes) {
        output_file << std::hex << std::setw(2) << std::setfill('0') << static_cast<unsigned int>(static_cast<unsigned char>(byte)) << " ";
    }
    output_file << std::endl;
});

std::this_thread::sleep_for(std::chrono::seconds(5));

peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
peripheral.disconnect();
output_file.close();

auto end_time = std::chrono::high_resolution_clock::now();
std::chrono::duration<double> elapsed_time = end_time - start_time;

std::cout << "Elapsed time for the notification period: " << elapsed_time.count() << " seconds" << std::endl;

return EXIT_SUCCESS; */








/*std::ofstream output_file("output.txt", std::ios::out | std::ios::binary);
auto start_time = std::chrono::high_resolution_clock::now();
std::stringstream buffer;

peripheral.notify(uuids[selection.value()].first, uuids[selection.value()].second, [&](SimpleBLE::ByteArray bytes) {
    std::cout << "Received: ";
    Utils::print_byte_array(bytes);

    // Write the received data in hexadecimal human-readable form to the buffer.
    for (const auto& byte : bytes) {
        buffer << std::hex << std::setw(2) << std::setfill('0') << static_cast<unsigned int>(static_cast<unsigned char>(byte)) << " ";
    }
    buffer << std::endl;
});

std::this_thread::sleep_for(std::chrono::seconds(5));

// Write the buffered data to the file.
output_file << buffer.str();

peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
peripheral.disconnect();
output_file.close();

auto end_time = std::chrono::high_resolution_clock::now();
std::chrono::duration<double> elapsed_time = end_time - start_time;

std::cout << "Elapsed time for the notification period: " << elapsed_time.count() << " seconds" << std::endl;

return EXIT_SUCCESS;*/



/*

#include <chrono>
#include <iomanip>
#include <iostream>
#include <thread>
#include <vector>
#include <fstream>
#include <sstream>
#include "../common/utils.hpp"

#include "simpleble/SimpleBLE.h"
#include <string>
#include <chrono>
#include <atomic>
#include <mutex>
#include <condition_variable>

using namespace std::chrono_literals;

// Global done variable
std::atomic<bool> done(false);

// Predicate function for the condition_variable wait function
bool is_done() { return done; }


int main() {
    auto adapter_optional = Utils::getAdapter();

    if (!adapter_optional.has_value()) {
        return EXIT_FAILURE;
    }

    auto adapter = adapter_optional.value();

    std::vector<SimpleBLE::Peripheral> peripherals;

    adapter.set_callback_on_scan_found([&](SimpleBLE::Peripheral peripheral) {
        std::cout << "Found device: " << peripheral.identifier() << " [" << peripheral.address() << "]" << std::endl;
        peripherals.push_back(peripheral);
    });

    adapter.set_callback_on_scan_start([]() { std::cout << "Scan started." << std::endl; });
    adapter.set_callback_on_scan_stop([]() { std::cout << "Scan stopped." << std::endl; });
    // Scan for 5 seconds and return.
    adapter.scan_for(5000);

    std::cout << "The following devices were found:" << std::endl;
    for (size_t i = 0; i < peripherals.size(); i++) {
        std::cout << "[" << i << "] " << peripherals[i].identifier() << " [" << peripherals[i].address() << "]"
                  << std::endl;
    }

    auto selection = Utils::getUserInputInt("Please select a device to connect to", peripherals.size() - 1);
    if (!selection.has_value()) {
        return EXIT_FAILURE;
    }

    auto peripheral = peripherals[selection.value()];
    std::cout << "Connecting to " << peripheral.identifier() << " [" << peripheral.address() << "]" << std::endl;
    peripheral.connect();

    std::cout << "Successfully connected, printing services and characteristics.." << std::endl;

    // Store all service and characteristic uuids in a vector.
    std::vector<std::pair<SimpleBLE::BluetoothUUID, SimpleBLE::BluetoothUUID>> uuids;
    for (auto service : peripheral.services()) {
        for (auto characteristic : service.characteristics()) {
            uuids.push_back(std::make_pair(service.uuid(), characteristic.uuid()));
        }
    }

    std::cout << "The following services and characteristics were found:" << std::endl;
    for (size_t i = 0; i < uuids.size(); i++) {
        std::cout << "[" << i << "] " << uuids[i].first << " " << uuids[i].second << std::endl;
    }

    selection = Utils::getUserInputInt("Please select a characteristic to read", uuids.size() - 1);

    if (!selection.has_value()) {
        return EXIT_FAILURE;
    }
    size_t buffer_size = 10000;
    std::cout << "Enter the number of buffers (5K samples each) to fill: ";
    size_t num_buffers_to_fill;
    std::cin >> num_buffers_to_fill;

    size_t total_bytes_received = 0;
    size_t total_notifications_received = 0;

    // Create a buffer to store received data temporarily
    std::vector<SimpleBLE::ByteArray> received_data_buffer;

    std::chrono::high_resolution_clock::time_point start_time, end_time;
    std::atomic<bool> done(false);
    std::mutex data_mutex;
    std::condition_variable done_cv;

    received_data_buffer.reserve(num_buffers_to_fill);

    peripheral.notify(uuids[selection.value()].first, uuids[selection.value()].second, [&](SimpleBLE::ByteArray bytes) {
        std::unique_lock<std::mutex> lock(data_mutex);
        std::cout << "Received: ";
        Utils::print_byte_array(bytes);
        if (total_notifications_received == 0) {
            // Store the start time of the first notification
            start_time = std::chrono::high_resolution_clock::now();
        }

        // Store the received data in the buffer
        received_data_buffer.push_back(bytes);

        total_bytes_received += bytes.size();
        total_notifications_received++;
        if (total_bytes_received >= num_buffers_to_fill * buffer_size) {
            peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
            end_time = std::chrono::high_resolution_clock::now();  // Store the end time
            done = true;
            done_cv.notify_one();
        }
    });

    std::unique_lock<std::mutex> lock(data_mutex);
    done_cv.wait(lock, [&]() { return done.load(); });

    // Use a separate thread to process the received data and write it to the output file
    std::thread processing_thread([&]() {
        std::ofstream output_file("wyniki_25_04.txt", std::ios::out | std::ios::binary);
        for (const auto& bytes : received_data_buffer) {
            for (const auto& byte : bytes) {
                output_file << std::hex << std::setw(2) << std::setfill('0')
                            << static_cast<unsigned int>(static_cast<unsigned char>(byte)) << " ";
            }
            output_file << std::endl;
        }
        output_file.close();
    });

    processing_thread.join();

    peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
    peripheral.disconnect();

    std::chrono::duration<double> elapsed_time = end_time - start_time;
    std::cout << "Elapsed time for the notification period: " << elapsed_time.count() << " seconds" << std::endl;

    return EXIT_SUCCESS;
}
* /


/*std::unique_lock<std::mutex> lock(data_mutex);
    done_cv.wait(lock, [&]() { return done.load(); });

    // Unsubscribe from the selected characteristic and disconnect
    peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
    peripheral.disconnect();

    // Use a separate thread to process the received data and write it to the output file
    std::thread processing_thread([&]() {
        std::ofstream output_file("wyniki_25_04.txt", std::ios::out | std::ios::binary);
        for (const auto& bytes : received_data_buffer) {
            for (const auto& byte : bytes) {
                output_file << std::hex << std::setw(2) << std::setfill('0')
                            << static_cast<unsigned int>(static_cast<unsigned char>(byte)) << " ";
            }
            output_file << std::endl;
        }
        output_file.close();
    });

    processing_thread.join();

    std::chrono::duration<double> elapsed_time = end_time - start_time;
    std::cout << "Elapsed time for the notification period: " << elapsed_time.count() << " seconds" << std::endl;
*/
/**/
#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <thread>
#include <vector>
#include "../common/utils.hpp"

#include <atomic>
#include <chrono>
#include <condition_variable>
#include <mutex>
#include <string>
#include "simpleble/SimpleBLE.h"

using namespace std::chrono_literals;


std::atomic<bool> done(false);

bool is_done() { return done; }

int main() {
    auto adapter_optional = Utils::getAdapter();

    if (!adapter_optional.has_value()) {
        return EXIT_FAILURE;
    }

    auto adapter = adapter_optional.value();

    std::vector<SimpleBLE::Peripheral> peripherals;

    adapter.set_callback_on_scan_found([&](SimpleBLE::Peripheral peripheral) {
        std::cout << "Znaleziono urzadzenia: " << peripheral.identifier() << " [" << peripheral.address() << "]"
                  << std::endl;
        ;
        peripherals.push_back(peripheral);
    });

    adapter.set_callback_on_scan_start([]() { std::cout << "Rozpoczeto skanowanie." << std::endl; });
    adapter.set_callback_on_scan_stop([]() { std::cout << "Zakonczono skanowanie." << std::endl; });
    // Scan for 5 seconds and return.
    adapter.scan_for(5000);

    std::cout << "Znaleziono nastepujace urzadzenia:" << std::endl;
    for (size_t i = 0; i < peripherals.size(); i++) {
        std::cout << "[" << i << "] " << peripherals[i].identifier() << " [" << peripherals[i].address() << "]"
                  << std::endl;
    }

    auto selection = Utils::getUserInputInt("Wybierz urzadzenie z ktorym chcesz nawiazac polaczenie", peripherals.size() - 1);
    if (!selection.has_value()) {
        return EXIT_FAILURE;
    }

    auto peripheral = peripherals[selection.value()];
    std::cout << "laczenie z " << peripheral.identifier() << " [" << peripheral.address() << "]" << std::endl;
    peripheral.connect();

    std::cout << "Udalo sie polaczyc z urzadzeniem, posiada ono nast�puace charakterystyki oraz seriwsy" << std::endl;

    // Store all service and characteristic uuids in a vector.
    std::vector<std::pair<SimpleBLE::BluetoothUUID, SimpleBLE::BluetoothUUID>> uuids;
    for (auto service : peripheral.services()) {
        for (auto characteristic : service.characteristics()) {
            uuids.push_back(std::make_pair(service.uuid(), characteristic.uuid()));
        }
    }

    std::cout << "Nast�pujace charakterystyki zostaly znalezione:" << std::endl;
    for (size_t i = 0; i < uuids.size(); i++) {
        std::cout << "[" << i << "] " << uuids[i].first << " " << uuids[i].second << std::endl;
    }

    selection = Utils::getUserInputInt("Wybierz charakterystyke do subskypcji", uuids.size() - 1);

    if (!selection.has_value()) {
        return EXIT_FAILURE;
    }
    size_t buffer_size = 5000;
    std::cout << "Podaj liczbe buforow do wype�nienia (kazdy posiada 5k sampli) : ";
    size_t num_buffers_to_fill;
    std::cin >> num_buffers_to_fill;


    size_t total_bytes_received = 0;
    size_t total_notifications_received = 0;
    std::string file_name;
    std::cout << "Wprowadz nazwe pliku, w ktorym zosan� zapisane dane: ";
    std::cin.ignore();  
    std::getline(std::cin, file_name);

    // zrob buffor
    std::vector<SimpleBLE::ByteArray> received_data_buffer;

        std::chrono::high_resolution_clock::time_point start_time, end_time;
    std::atomic<bool> done(false);
    std::mutex data_mutex;
    std::condition_variable done_cv;

    received_data_buffer.reserve(num_buffers_to_fill);

    peripheral.notify(uuids[selection.value()].first, uuids[selection.value()].second, [&](SimpleBLE::ByteArray bytes) {
        std::unique_lock<std::mutex> lock(data_mutex);
        std::cout << "Otrzymano: ";
        Utils::print_byte_array(bytes);
        if (total_notifications_received == 0) {
            // 
            start_time = std::chrono::high_resolution_clock::now();
        }

      // wpisz dane do buffora
        received_data_buffer.push_back(bytes);

        total_bytes_received += bytes.size();
        total_notifications_received++;
        if (total_bytes_received >= num_buffers_to_fill * buffer_size) {
            peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
            end_time = std::chrono::high_resolution_clock::now();  // Store the end time
            done = true;
            done_cv.notify_one();
        }
    });

    std::unique_lock<std::mutex> lock(data_mutex);
    done_cv.wait(lock, [&]() { return done.load(); });

    peripheral.unsubscribe(uuids[selection.value()].first, uuids[selection.value()].second);
    peripheral.disconnect();

    //zapisz dane do pliku
    std::ofstream output_file(file_name, std::ios::out | std::ios::binary);
    for (const auto& bytes : received_data_buffer) {
        for (const auto& byte : bytes) {
            output_file << std::hex << std::setw(2) << std::setfill('0')
                        << static_cast<unsigned int>(static_cast<unsigned char>(byte)) << " ";
        }
        output_file << std::endl;
    }
    output_file.close();

    std::chrono::duration<double> elapsed_time = end_time - start_time;
    std::cout << "Czas notyfikacji wyniosl : " << elapsed_time.count() << " s" << std::endl;

    return EXIT_SUCCESS;
}
